package tables;

public class Romantic extends Table {
    public Romantic(int occupancy) {
        super.capacity = 2;
        super.occupancy = occupancy;
    }
}
