package tables;

public class Family extends Table {
    public Family(int occupancy) {
        super.capacity = 10;
        super.occupancy = occupancy;
    }
}
