package tables;

public class General extends Table {
    public General(int occupancy) {
        super.capacity = 4;
        super.occupancy = occupancy;
    }
}
