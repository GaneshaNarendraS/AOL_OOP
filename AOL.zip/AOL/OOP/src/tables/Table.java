package tables;

public abstract class Table {
    int capacity;
    int occupancy;
    public int getCapacity() {
        return capacity;
    }
    public int getOccupancy() {
        return occupancy;
    }
}
