package info;

public enum OrderState {
    inReserve,
    inOrder,
    finalized
}
