package info;

public enum BranchLocation {
    Bandung(true),
    Jakarta(true),
    Kuta(true),
    Surabaya(false),
    Samarinda(false),
    Padang(false);

    private final boolean spesial;
    BranchLocation(boolean spesial) {
        this.spesial = spesial;
    }
    public boolean isSpesial() {
        return spesial;
    }
}
