package main;

import info.BranchLocation;
import info.OrderState;
import dish.LocalDish;
import dish.Dish;
import dish.SpecialDish;
import tables.Family;
import tables.General;
import tables.Table;
import tables.Romantic;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    private static final Diner bandung = new Diner(BranchLocation.Bandung);
    private static final Diner jakarta = new Diner(BranchLocation.Jakarta);
    private static final Diner kuta = new Diner(BranchLocation.Kuta);
    private static final Diner surabaya = new Diner(BranchLocation.Surabaya);
    private static final Diner samarinda = new Diner(BranchLocation.Samarinda);
    private static final Diner padang = new Diner(BranchLocation.Padang);
    private static final ArrayList<StaffMember> listStaffMember = new ArrayList<>();
    private static StaffMember activeStaffMember;
    private static Diner activeDiner;
    private static final Scanner Scanner = new Scanner(System.in);

    private static int getUserInput(int max) {
        int opt = -1;
        do {
            System.out.print(">> ");
            try {
                opt = Scanner.nextInt();
            } catch (Exception ignored) {
            }
            Scanner.nextLine();
        } while (opt < 0 || opt > max);
        return opt;
    }

    private static int getUserInput(int min, int max, String message) {
        int opt = -1;
        do {
            System.out.print(message);
            try {
                opt = Scanner.nextInt();
            } catch (Exception ignored) {
            }
            Scanner.nextLine();
        } while (opt < min || opt > max);
        return opt;
    }

    private static double getFloatInput(int min, double max, String message) {
        double opt = -1;
        do {
            System.out.print(message);
            try {
                opt = Scanner.nextDouble();
            } catch (Exception ignored) {
            }
            Scanner.nextLine();
        } while (opt < min || opt > max);
        return opt;
    }

    public static void setupStaff(String[] args) {
        listStaffMember.add(new StaffMember("BA001", "EmpBandung", BranchLocation.Bandung));
        listStaffMember.add(new StaffMember("JA001", "EmpJakarta", BranchLocation.Jakarta));
        listStaffMember.add(new StaffMember("KU001", "EmpKuta", BranchLocation.Kuta));
        listStaffMember.add(new StaffMember("SU001", "EmpSurabaya", BranchLocation.Surabaya));
        listStaffMember.add(new StaffMember("SA001", "EmpSamarinda", BranchLocation.Samarinda));
        listStaffMember.add(new StaffMember("PA001", "EmpPadang", BranchLocation.Padang));

        int opt;
        while (true) {
            System.out.println("\nLaperAh (weird ahh name)");
            System.out.println("===================");
            System.out.println("1. View Reservations");
            System.out.println("2. New Reservation");
            System.out.println("3. View Orders");
            System.out.println("4. New Order");
            System.out.println("5. Checkout");
            System.out.println("6. Modify Dish");
            System.out.println("0. Exit");
            opt = getUserInput(6);
            if (opt == 0) {
                break;
            }

            staffLogin();
            switch (opt) {
                case 1:
                    viewReservation(false);
                    break;
                case 2:
                    newReservation();
                    break;
                case 3:
                    viewReservation(true);
                    break;
                case 4:
                    newOrder();
                    break;
                case 5:
                    checkout();
                    break;
                case 6:
                    modify();
                    break;
                default:
                    break;
            }
        }
    }

    private static void modify() {
        System.out.println("\nDish Modifications:");
        System.out.println("1. Name");
        System.out.println("2. Price");
        System.out.println("3. Delete");
        System.out.println("4. Add");
        System.out.println("0. Back");
        int opt = getUserInput(4);

        boolean valid;
        int DishIndex;
        switch (opt) {
            case 1:
                viewDish();
                valid = false;
                do {
                    DishIndex = 0;
                    System.out.print("Input Dish ID to Change Name: ");
                    String DishId = Scanner.nextLine();
                    for (Dish Dish : activeDiner.getListDish()) {
                        if (Dish.getDishId().equals(DishId)) {
                            valid = true;
                            break;
                        }
                        DishIndex++;
                    }
                } while (!valid);
                System.out.print("Input New Name: ");
                String name = Scanner.nextLine();
                activeDiner.getListDish().get(DishIndex).setName(name);
                break;
            case 2:
                viewDish();
                valid = false;
                do {
                    DishIndex = 0;
                    System.out.print("Input Dish ID to Change Price: ");
                    String DishId = Scanner.nextLine();
                    for (Dish Dish : activeDiner.getListDish()) {
                        if (Dish.getDishId().equals(DishId)) {
                            valid = true;
                            break;
                        }
                        DishIndex++;
                    }
                } while (!valid);
                double price = getFloatInput(0, Double.MAX_VALUE, "Input New Price: ");
                activeDiner.getListDish().get(DishIndex).setName(price);
                break;
            case 3:
                viewDish();
                valid = false;
                do {
                    System.out.print("Input Dish ID to Delete (0 to cancel): ");
                    String DishId = Scanner.nextLine();
                    if (DishId.equals("0")) {
                        break;
                    }
                    for (Dish Dish : activeDiner.getListDish()) {
                        if (Dish.getDishId().equals(DishId)) {
                            if (Dish.hasBeenOrdered()) {
                                System.out.println("Dish in Order, Cannot Delete");
                                break;
                            }
                            activeDiner.getListDish().remove(Dish);
                            valid = true;
                            break;
                        }
                    }
                } while (!valid);
                break;
            case 4:
                addDish();
                break;
            default:
                break;
        }
    }

    private static void addDish() {
        String name;
        System.out.print("Input Dish Name: ");
        name = Scanner.nextLine();
        double price = getFloatInput(0, Double.MAX_VALUE, "Input Dish Price: ");
        while (true) {
            System.out.println("Dish is Special [yes | no]: ");
            String opt  = Scanner.nextLine();
            if (opt.equals("yes")) {
                String description = Scanner.nextLine();
                System.out.println("Input Dish Description: ");
                if (!activeStaffMember.getBranchLocation().isSpesial()) {
                    System.out.println("Input Dish Location Source: ");
                    String source = Scanner.nextLine();
                    LocalDish newDish = new LocalDish(String.format("%c%03d", name.toUpperCase().charAt(0), activeDiner.getListDish().size()), name, price, description, source);
                    activeDiner.getListDish().add(newDish);
                    break;
                }
                SpecialDish newDish = new SpecialDish(String.format("%c%03d", name.toUpperCase().charAt(0), activeDiner.getListDish().size()), name, price, description);
                activeDiner.getListDish().add(newDish);
                break;
            } else if (opt.equals("no")) {
                break;
            }
        }
        Dish newDish = new Dish(String.format("%c%03d", name.toUpperCase().charAt(0), activeDiner.getListDish().size()), name, price);
        activeDiner.getListDish().add(newDish);
    }

    private static void checkout() {
        viewReservation(true);
        String id;
        boolean valid = false;
        do {
            System.out.print("Input Order ID to Checkout: ");
            id = Scanner.nextLine();
            int i = 0;
            for (Orders pesan : activeDiner.getListOrders()) {
                if (pesan.getId().equals(id)) {
                    activeDiner.getListOrders().get(i).setStatus(OrderState.finalized);
                    pesan.viewReceipt();
                    System.out.println("Checkout Successful");
                    valid = true;
                }
                i++;
            }
        } while (!valid);
    }

    private static void viewDish() {
        for (Dish Dish : activeDiner.getListDish()) {
            System.out.println("\nDish ID: " + Dish.getDishId());
            System.out.println("Name: " + Dish.getDishName());
            System.out.printf("Price: %.2f\n", Dish.getPrice());
            if (Dish instanceof SpecialDish) {
                System.out.println("Description:");
                System.out.println(((SpecialDish) Dish).getNarrative());
            }
            if (Dish instanceof LocalDish) {
                System.out.println("Origin: " + ((LocalDish) Dish).getlocation());
                System.out.println("Description:");
                System.out.println(((LocalDish) Dish).getnarrative());
            }
        }
    }

    private static void newOrder() {
        System.out.println("\nNew Order for:");
        System.out.println("1. Existing Reservation");
        System.out.println("2. New Reservation");
        int opt = getUserInput(1, 2, ">> ");

        Orders Orders = null;
        if (opt == 1) {
            viewReservation(false);
            String id;
            boolean valid = false;
            do {
                System.out.print("Input Reservation ID: ");
                id = Scanner.nextLine();
                for (Orders pesan : activeDiner.getListOrders()) {
                    if (pesan.getId().equals(id)) {
                        Orders = pesan;
                        valid = true;
                        break;
                    }
                }
            } while (!valid);
        } else {
            Orders = newReservation();
        }

        viewDish();
        String DishId;
        do {
            System.out.print("Input Dish ID to Add (0 to finish): ");
            DishId = Scanner.nextLine();
            int DishIndex = 0;
            for (Dish Dish : activeDiner.getListDish()) {
                if (Dish.getDishId().equals(DishId)) {
                    activeDiner.getListDish().get(DishIndex).setOrdered(true);
                    Orders.addDish(Dish);
                    Orders.setStatus(OrderState.inOrder);
                }
                DishIndex++;
            }
        } while (!DishId.equals("0"));

        int pesanIndex = 0;
        for (Orders pesan : activeDiner.getListOrders()) {
            if (pesan.getId().equals(Orders.getId())) {
                activeDiner.getListOrders().set(pesanIndex, Orders);
                break;
            }
            pesanIndex++;
        }
    }

    private static Orders newReservation() {
        System.out.println();
        System.out.print("Customer Name: ");
        String name = Scanner.nextLine();
        Orders Orders = new Orders(activeStaffMember, name, activeDiner.getListOrders().size());
        int tables = -1;
        do {
            System.out.print("Number of Tables: ");
            try {
                tables = Scanner.nextInt();
            } catch (Exception ignored) {
            }
            Scanner.nextLine();
        } while (tables < 1);
        for (int i = 0; i < tables; i++) {
            System.out.println("\nTable " + i + 1);
            int capacity;
            Table Table = null;
            do {
                System.out.print("Table type [Romantic | General | Family]: ");
                String type = Scanner.nextLine();
                capacity = getUserInput(1, Integer.MAX_VALUE, "Number of person: ");
                Table = switch (type) {
                    case "Romantic" -> new Romantic(capacity);
                    case "General" -> new General(capacity);
                    case "Family" -> new Family(capacity);
                    default -> Table;
                };
            } while (Table == null || Table.getCapacity() < capacity);
            Orders.addTable(Table);
        }
        activeDiner.getListOrders().add(Orders);
        return Orders;
    }

    private static void viewReservation(boolean order) {
        System.out.println("\nReservations:");
        for (Orders Orders : activeDiner.getListOrders()) {
            if (Orders.getStatus() == OrderState.finalized) {
                continue;
            }
            if (!order && Orders.getStatus() == OrderState.inOrder) {
                continue;
            }
            if (order && Orders.getStatus() == OrderState.inReserve) {
                continue;
            }
            Orders.view();
        }
    }

    private static void staffLogin() {
        String id;
        activeStaffMember = null;
        System.out.println();
        while (true) {
            System.out.print("Input StaffMember ID: ");
            id = Scanner.nextLine();
            for (StaffMember emp : listStaffMember) {
                if (emp.getId().equals(id)) {
                    activeStaffMember = emp;
                    switch (emp.getBranchLocation().name()) {
                        case "Bandung":
                            activeDiner = bandung;
                            break;
                        case "Jakarta":
                            activeDiner = jakarta;
                            break;
                        case "Kuta":
                            activeDiner = kuta;
                            break;
                        case "Surabaya":
                            activeDiner = surabaya;
                            break;
                        case "Samarinda":
                            activeDiner = samarinda;
                            break;
                        case "Padang":
                            activeDiner = padang;
                            break;
                    }
                    break;
                }
            }
            if (activeStaffMember == null) {
                System.out.println("Invalid ID");
                continue;
            }
            return;
        }
    }
}