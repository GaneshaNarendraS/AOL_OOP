package main;

import info.BranchLocation;
import dish.Dish;

import java.util.ArrayList;

public class Diner {
    private final ArrayList<Dish> listDish = new ArrayList<>();
    private final ArrayList<Orders> listOrders = new ArrayList<>();
    private final BranchLocation BranchLocation;

    public Diner(BranchLocation BranchLocation) {
        this.BranchLocation = BranchLocation;
    }

    public ArrayList<Dish> getListDish() {
        return listDish;
    }

    public ArrayList<Orders> getListOrders() {
        return listOrders;
    }

    public BranchLocation getBranchLocation() {
        return BranchLocation;
    }
}
