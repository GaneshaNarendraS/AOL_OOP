package main;

import info.OrderState;
import dish.Dish;
import tables.Table;

import java.util.ArrayList;

public class Orders {
    private final String id;
    private final StaffMember StaffMember;
    private final String customerName;
    private final ArrayList<Table> listTable = new ArrayList<>();
    private OrderState status = OrderState.inReserve;
    private final ArrayList<Dish> listDish = new ArrayList<>();

    public Orders(StaffMember StaffMember, String name, int num) {
        this.StaffMember = StaffMember;
        customerName = name;
        id = String.format("%c%03d", StaffMember.getBranchLocation().name().charAt(0), num + 1);
    }

    public String getId() {
        return id;
    }

    public StaffMember getStaffMember() {
        return StaffMember;
    }

    public ArrayList<Dish> getListDish() {
        return listDish;
    }

    public ArrayList<Table> getListTable() {
        return listTable;
    }

    public String getCustomerName() {
        return customerName;
    }

    public OrderState getStatus() {
        return status;
    }

    public void setStatus(OrderState status) {
        this.status = status;
    }

    public void addTable(Table Table) {
        listTable.add(Table);
    }

    public void addDish(Dish Dish) {
        if (status == OrderState.inReserve) {
            status = OrderState.inOrder;
        }
        listDish.add(Dish);
    }

    public void view() {
        System.out.println("\nOrder ID: " + id);
        System.out.println("\nStaffMember ID: " + StaffMember.getId());
        System.out.println("Customer Name: " + customerName);
        System.out.println("Status: " + status.name());
        if (status == OrderState.inOrder) {
            System.out.println("\nItems:");
            for (Dish Dish : listDish) {
                System.out.println(Dish.getDishId() + " | " + Dish.getDishName() + " | " + Dish.getPrice());
            }
        }
    }

    public void viewReceipt() {
        System.out.println("\nOrder ID: " + id);
        System.out.println("\nStaffMember ID: " + StaffMember.getId());
        System.out.println("Customer Name: " + customerName);
        System.out.println("Status: " + status.name());
        System.out.println("\nItems:");
        double sum = 0;
        for (Dish Dish : listDish) {
            System.out.println(Dish.getDishId() + " | " + Dish.getDishName() + " | " + Dish.getPrice());
            sum += Dish.getPrice();
        }
        System.out.printf("\nTotal: %.2f\n", sum);
    }
}
