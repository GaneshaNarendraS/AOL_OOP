package main;

import info.BranchLocation;

public class StaffMember {
    private final String id;
    private final String name;
    private final BranchLocation BranchLocation;

    public StaffMember(String id, String name, BranchLocation BranchLocation) {
        this.id = id;
        this.name = name;
        this.BranchLocation = BranchLocation;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public BranchLocation getBranchLocation() {
        return BranchLocation;
    }
}
