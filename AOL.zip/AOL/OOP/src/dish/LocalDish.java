package dish;

public class LocalDish extends Dish {
    private final String narrative;
    private final String location;

    public LocalDish(String id, String name, double price, String narrative, String location) {
        super(id, name, price);
        this.narrative = narrative;
        this.location = location;
    }

    public String getnarrative() {
        return narrative;
    }

    public String getlocation() {
        return location;
    }
}
