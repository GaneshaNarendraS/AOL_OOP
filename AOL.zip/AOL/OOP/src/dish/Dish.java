package dish;

public class Dish {
    private final String dishId;
    private String dishName;
    private double dishCost;
    private boolean orderStatus;

    public Dish(String dishId, String dishName, double dishCost) {
        this.dishId = dishId;
        this.dishName = dishName;
        this.dishCost = dishCost;
    }

    public String getDishId() {
        return dishId;
    }

    public String getDishName() {
        return dishName;
    }

    public double getDishCost() {
        return dishCost;
    }

    public boolean hasBeenOrdered() {
        return orderStatus;
    }

    public void updateDishName(String dishName) {
        this.dishName = dishName;
    }

    public void updateDishCost(double dishCost) {
        this.dishCost = dishCost;
    }

    public void updateOrderStatus(boolean orderStatus) {
        this.orderStatus = orderStatus;
    }

	public int getPrice() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void setName(double price) {
		// TODO Auto-generated method stub
		
	}

	public void setName(String name) {
		// TODO Auto-generated method stub
		
	}

	public String getPrice11() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setOrdered(boolean b) {
		// TODO Auto-generated method stub
		
	}

	public Object getPrice1() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setName1(String name) {
		// TODO Auto-generated method stub
		
	}
}
