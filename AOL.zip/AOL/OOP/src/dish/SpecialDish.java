package dish;

public class SpecialDish extends Dish {
    private final String Narrative;

    public SpecialDish(String id, String name, double price, String Narrative) {
        super(id, name, price);
        this.Narrative = Narrative;
    }

    public String getNarrative() {
        return Narrative;
    }
}
